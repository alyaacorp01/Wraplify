import { useMemo } from 'react';
import type { CSSProperties } from 'react';
import { Heart } from 'lucide-react';

interface EffectsLayerProps {
  animation: string;
  density?: 'low' | 'high';
  className?: string;
}

interface Particle {
  left: number;
  top: number;
  delay: number;
  duration: number;
  size: number;
  color: string;
  drift: number;
  opacity: number;
}

const PALETTES: Record<string, string[]> = {
  confetti: ['#f43f5e', '#f59e0b', '#10b981', '#3b82f6', '#a855f7', '#facc15', '#ec4899'],
  balloons: ['#f43f5e', '#fb7185', '#f59e0b', '#8b5cf6', '#38bdf8', '#fb923c'],
  hearts: ['#f43f5e', '#fb7185', '#f9a8d4', '#e11d48', '#fda4af'],
  petals: ['#f9a8d4', '#f472b6', '#fbcfe8', '#fb7185'],
  bubbles: ['#bae6fd', '#e0f2fe', '#fbcfe8', '#ddd6fe'],
  fireworks: ['#fbbf24', '#f472b6', '#a78bfa', '#67e8f9', '#fda4af'],
  sparkles: ['#fde68a', '#fbcfe8', '#ffffff', '#f9a8d4', '#fef3c7'],
};

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function cssVars(p: Particle): CSSProperties {
  return {
    left: `${p.left}%`,
    animationDelay: `${p.delay}s`,
    animationDuration: `${p.duration}s`,
    opacity: p.opacity,
    ['--drift' as string]: `${p.drift}px`,
    ['--o' as string]: p.opacity,
  } as CSSProperties;
}

export default function EffectsLayer({ animation, density = 'high', className = '' }: EffectsLayerProps) {
  const count = density === 'high' ? 26 : 12;
  const particles = useMemo<Particle[]>(() => {
    const palette = PALETTES[animation] ?? ['#f9a8d4'];
    return Array.from({ length: count }, () => ({
      left: rand(1, 98),
      top: rand(2, 96),
      delay: rand(0, 9),
      duration: rand(5, 12),
      size: rand(8, 22),
      color: palette[Math.floor(Math.random() * palette.length)],
      drift: rand(-70, 70),
      opacity: rand(0.45, 1),
    }));
  }, [animation, count]);

  if (!animation || animation === 'none') return null;

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {animation === 'hearts' &&
        particles.map((p, i) => (
          <span key={i} className="fx-rise absolute top-full" style={cssVars(p)}>
            <Heart size={p.size} fill={p.color} color={p.color} strokeWidth={1} />
          </span>
        ))}

      {animation === 'confetti' &&
        particles.map((p, i) => (
          <span
            key={i}
            className="fx-fall absolute -top-[6%] block rounded-[3px]"
            style={{ ...cssVars(p), width: p.size * 0.55, height: p.size, background: p.color } as CSSProperties}
          />
        ))}

      {animation === 'sparkles' &&
        particles.map((p, i) => (
          <span
            key={i}
            className="fx-twinkle absolute select-none font-bold"
            style={{ ...cssVars(p), top: `${p.top}%`, fontSize: p.size + 6, color: p.color, textShadow: `0 0 12px ${p.color}` } as CSSProperties}
          >
            ✦
          </span>
        ))}

      {animation === 'petals' &&
        particles.map((p, i) => (
          <span
            key={i}
            className="fx-sway-fall absolute -top-[6%] block"
            style={{ ...cssVars(p), width: p.size * 0.8, height: p.size, background: p.color, borderRadius: '70% 4px 70% 4px' } as CSSProperties}
          />
        ))}

      {animation === 'snow' &&
        particles.map((p, i) => (
          <span
            key={i}
            className="fx-sway-fall absolute -top-[6%] block rounded-full bg-white"
            style={{ ...cssVars(p), width: p.size * 0.45, height: p.size * 0.45, boxShadow: '0 0 8px rgba(255,255,255,.9)' } as CSSProperties}
          />
        ))}

      {animation === 'balloons' &&
        particles.slice(0, 10).map((p, i) => (
          <span key={i} className="fx-rise absolute top-full flex flex-col items-center" style={cssVars(p)}>
            <span
              className="block"
              style={{ width: p.size * 1.7, height: p.size * 2.1, background: `radial-gradient(circle at 32% 28%, rgba(255,255,255,.75), transparent 46%), ${p.color}`, borderRadius: '50% 50% 48% 48%' }}
            />
            <span className="block h-10 w-px bg-current opacity-40" style={{ color: p.color }} />
          </span>
        ))}

      {animation === 'fireworks' &&
        particles.slice(0, 10).map((p, i) => (
          <span key={i} className="absolute" style={{ left: `${p.left}%`, top: `${p.top}%` }}>
            <span
              className="fx-ring absolute block rounded-full"
              style={{ width: p.size * 6, height: p.size * 6, marginLeft: -(p.size * 3), marginTop: -(p.size * 3), border: `3px solid ${p.color}`, boxShadow: `0 0 18px ${p.color}`, animationDelay: `${p.delay}s`, animationDuration: `${Math.max(2.2, p.duration / 3)}s` }}
            />
            <span
              className="fx-twinkle absolute block rounded-full"
              style={{ width: 6, height: 6, marginLeft: -3, marginTop: -3, background: p.color, animationDelay: `${p.delay}s`, animationDuration: '1.6s' }}
            />
          </span>
        ))}

      {animation === 'bubbles' &&
        particles.map((p, i) => (
          <span
            key={i}
            className="fx-wobble-rise absolute top-full block rounded-full"
            style={{ ...cssVars(p), width: p.size, height: p.size, border: `2px solid ${p.color}`, background: `${p.color}33` } as CSSProperties}
          />
        ))}
    </div>
  );
}
