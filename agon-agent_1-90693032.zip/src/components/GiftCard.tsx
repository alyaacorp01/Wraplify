import type { CSSProperties } from 'react';
import { Camera, Heart, Music } from 'lucide-react';
import { giftTypeById, musicById, themeById } from '../lib/giftData';

export interface GiftCardData {
  recipient_name?: string;
  sender_name?: string;
  message?: string;
  gift_type?: string;
  theme_id?: string;
  background_id?: string;
  photos?: string[];
  music_id?: string;
}

function hexA(hex: string, alpha: string) {
  return hex.length === 7 ? `${hex}${alpha}` : hex;
}

function patternStyle(bgId: string | undefined, accent: string, dark: boolean): CSSProperties | null {
  const a = accent.replace('#', '%23');
  switch (bgId) {
    case 'glow':
      return {
        background: `radial-gradient(420px 220px at 18% 8%, ${hexA(accent, dark ? '44' : '30')}, transparent 70%), radial-gradient(480px 260px at 85% 90%, ${hexA(accent, dark ? '38' : '26')}, transparent 70%)`,
      };
    case 'dots':
      return {
        backgroundImage: `radial-gradient(${hexA(accent, '66')} 1.6px, transparent 1.7px)`,
        backgroundSize: '26px 26px',
      };
    case 'stars':
      return {
        backgroundImage: `radial-gradient(rgba(255,255,255,.95) 1.3px, transparent 1.4px), radial-gradient(${hexA(accent, '88')} 1.3px, transparent 1.4px)`,
        backgroundSize: '90px 90px, 56px 56px',
        backgroundPosition: '0 0, 28px 20px',
      };
    case 'hearts': {
      const heartSvg = `<svg xmlns='http://www.w3.org/2000/svg' width='52' height='52' viewBox='0 0 24 24'><path d='M12 21C12 21 4 15.5 4 9.5 4 6.5 6.5 4.5 9 4.5c1.5 0 2.5.7 3 1.5.5-.8 1.5-1.5 3-1.5 2.5 0 5 2 5 5 0 6-8 11.5-8 11.5z' fill='${a}' fill-opacity='0.20'/></svg>`;
      return { backgroundImage: `url("data:image/svg+xml,${heartSvg.replace(/#/g, '%23')}")`, backgroundSize: '52px 52px' };
    }
    case 'waves': {
      const waveSvg = `<svg xmlns='http://www.w3.org/2000/svg' width='120' height='28' viewBox='0 0 120 28'><path d='M0 14 Q 15 4 30 14 T 60 14 T 90 14 T 120 14' fill='none' stroke='${a}' stroke-opacity='0.28' stroke-width='2.5' stroke-linecap='round'/></svg>`;
      return { backgroundImage: `url("data:image/svg+xml,${waveSvg.replace(/#/g, '%23')}")`, backgroundSize: '120px 28px' };
    }
    default:
      return null;
  }
}

export function PatternOverlay({ bgId, accent, dark }: { bgId: string | undefined; accent: string; dark: boolean }) {
  const style = patternStyle(bgId, accent, dark);
  if (!style) return null;
  return <div className="pointer-events-none absolute inset-0" style={style} aria-hidden="true" />;
}

export default function GiftCard({ gift, compact = false }: { gift: GiftCardData; compact?: boolean }) {
  const theme = themeById(gift.theme_id || 'blush-rose');
  const type = giftTypeById(gift.gift_type || 'love');
  const music = musicById(gift.music_id || 'none');
  const photos = gift.photos ?? [];
  const recipient = gift.recipient_name?.trim() || 'Someone Special';
  const sender = gift.sender_name?.trim() || 'Someone who cares';
  const message = gift.message?.trim() || 'Your heartfelt message will appear here…';

  return (
    <div
      className="relative overflow-hidden rounded-3xl shadow-2xl"
      style={{ background: theme.bg, border: `1px solid ${hexA(theme.accent, '44')}` }}
    >
      <PatternOverlay bgId={gift.background_id} accent={theme.accent} dark={theme.dark} />
      <div className={`relative ${compact ? 'p-5' : 'p-6 sm:p-8'}`}>
        <div className="flex items-center justify-center gap-2">
          <span
            className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em]"
            style={{ background: theme.soft, color: theme.accent, border: `1px solid ${hexA(theme.accent, '55')}` }}
          >
            <Heart size={12} fill="currentColor" />
            {type.name}
          </span>
        </div>

        <p className="mt-3 text-center text-xs font-medium uppercase tracking-[0.3em]" style={{ color: theme.muted }}>
          A gift for
        </p>
        <h3 className={`text-center font-script leading-tight ${compact ? 'text-4xl' : 'text-5xl sm:text-6xl'}`} style={{ color: theme.ink }}>
          {recipient}
        </h3>

        <div
          className={`mx-auto mt-4 max-w-md rounded-2xl backdrop-blur-sm ${compact ? 'p-4' : 'p-5 sm:p-6'}`}
          style={{ background: theme.card, border: `1px solid ${hexA(theme.accent, '33')}`, boxShadow: '0 12px 40px rgba(0,0,0,0.10)' }}
        >
          <p className={`whitespace-pre-line text-center font-display leading-relaxed ${compact ? 'text-[15px]' : 'text-base sm:text-lg'}`} style={{ color: theme.ink }}>
            “{message}”
          </p>
        </div>

        {photos.length > 0 ? (
          <div className={`mx-auto mt-4 grid max-w-md gap-2 ${photos.length === 1 ? 'grid-cols-1' : photos.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
            {photos.slice(0, 3).map((src, i) => (
              <div
                key={i}
                className={`overflow-hidden rounded-xl border-2 border-white/80 shadow-lg ${photos.length >= 3 && i === 0 ? 'col-span-2 row-span-2' : ''} ${photos.length >= 3 ? 'aspect-square' : 'aspect-[4/3]'}`}
              >
                <img src={src} alt={`Gift memory ${i + 1}`} className="h-full w-full object-cover" loading="lazy" />
              </div>
            ))}
          </div>
        ) : (
          <div
            className="mx-auto mt-4 flex max-w-md items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-4 py-5 text-sm"
            style={{ borderColor: hexA(theme.accent, '55'), color: theme.muted, background: theme.dark ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.5)' }}
          >
            <Camera size={16} />
            <span>Your photos will appear here</span>
          </div>
        )}

        <div className="mt-5 flex flex-col items-center gap-2">
          <p className="text-sm" style={{ color: theme.muted }}>
            With love, <span className="font-script text-2xl" style={{ color: theme.ink }}>{sender}</span>
          </p>
          {music.url && (
            <span className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium" style={{ background: theme.soft, color: theme.muted }}>
              <Music size={12} /> {music.name} plays on open
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
