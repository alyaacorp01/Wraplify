import { Link } from 'react-router-dom';
import { Gift, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#170d1a] text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-rose-400 via-rose-500 to-fuchsia-600 text-white shadow-lg">
              <Gift size={19} strokeWidth={2.4} />
            </span>
            <span className="font-display text-2xl font-bold">Wraply</span>
          </div>
          <p className="mt-4 max-w-sm text-[15px] leading-relaxed text-white/60">
            Create a digital gift. Get a link. Send it to someone special. No accounts, no apps — just heartfelt moments, beautifully wrapped.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-widest text-white/40">Create</h4>
          <ul className="mt-4 space-y-2.5 text-[15px]">
            <li><Link to="/create" className="text-white/75 hover:text-rose-300">New gift</Link></li>
            <li><Link to="/create?type=birthday" className="text-white/75 hover:text-rose-300">Birthday gift</Link></li>
            <li><Link to="/create?type=love" className="text-white/75 hover:text-rose-300">Gift for your love</Link></li>
            <li><Link to="/create?type=anniversary" className="text-white/75 hover:text-rose-300">Anniversary gift</Link></li>
            <li><Link to="/create?type=thanks" className="text-white/75 hover:text-rose-300">Thank-you gift</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold uppercase tracking-widest text-white/40">Explore</h4>
          <ul className="mt-4 space-y-2.5 text-[15px]">
            <li><a href="/#how" className="text-white/75 hover:text-rose-300">How it works</a></li>
            <li><a href="/#occasions" className="text-white/75 hover:text-rose-300">Occasions</a></li>
            <li><a href="/#demo" className="text-white/75 hover:text-rose-300">Live demo</a></li>
            <li><Link to="/" className="text-white/75 hover:text-rose-300">Home</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-sm text-white/45 sm:flex-row sm:px-6 lg:px-8">
          <p>© 2026 Wraply. Wrap feelings, not just presents.</p>
          <p className="inline-flex items-center gap-1.5">
            Made with <Heart size={14} className="text-rose-400" fill="currentColor" /> for people you love
          </p>
        </div>
      </div>
    </footer>
  );
}
