import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Gift, Menu, X } from 'lucide-react';

const LINKS = [
  { label: 'Occasions', href: '/#occasions' },
  { label: 'How it works', href: '/#how' },
  { label: 'Live demo', href: '/#demo' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const onHome = location.pathname === '/';

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-rose-100/70 bg-white/75 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-rose-400 via-rose-500 to-fuchsia-600 text-white shadow-lg shadow-rose-500/30">
            <Gift size={19} strokeWidth={2.4} />
          </span>
          <span className="font-display text-2xl font-bold tracking-tight text-stone-900">
            Wraply
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <a key={l.label} href={onHome ? l.href.replace('/', '') : l.href} className="text-[15px] font-medium text-stone-600 transition hover:text-rose-600">
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden md:block">
          <Link
            to="/create"
            className="inline-flex items-center gap-2 rounded-full bg-stone-900 px-6 py-2.5 text-[15px] font-semibold text-white shadow-lg transition hover:bg-rose-600 hover:shadow-rose-500/30"
          >
            <Gift size={16} />
            Create a Gift
          </Link>
        </div>

        <button
          className="rounded-lg p-2 text-stone-700 hover:bg-rose-50 md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-rose-100 bg-white/95 px-4 pb-5 pt-3 backdrop-blur-xl md:hidden">
          <div className="flex flex-col gap-1">
            {LINKS.map((l) => (
              <a
                key={l.label}
                href={onHome ? l.href.replace('/', '') : l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-base font-medium text-stone-700 hover:bg-rose-50"
              >
                {l.label}
              </a>
            ))}
            <Link
              to="/create"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-stone-900 px-6 py-3 text-base font-semibold text-white"
            >
              <Gift size={17} /> Create a Gift
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
