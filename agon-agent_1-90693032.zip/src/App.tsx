import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import CreateGift from './pages/CreateGift';
import SharePage from './pages/SharePage';
import ViewGift from './pages/ViewGift';

function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.querySelector(hash);
      if (el) {
        window.setTimeout(() => el.scrollIntoView({ behavior: 'smooth' }), 80);
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/create" element={<CreateGift />} />
        <Route path="/created/:code" element={<SharePage />} />
        <Route path="/g/:code" element={<ViewGift />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </BrowserRouter>
  );
}
