import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  AlertCircle, AtSign, Check, Copy, ExternalLink, Eye, Gift, Globe, Loader2,
  Mail, MessageCircle, MessageSquare, PartyPopper, Send, Share2,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import GiftCard from '../components/GiftCard';
import EffectsLayer from '../components/EffectsLayer';
import type { Gift as GiftType } from '../lib/giftData';
import { fetchGift } from '../lib/api';

export default function SharePage() {
  const { code } = useParams<{ code: string }>();
  const [gift, setGift] = useState<GiftType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [canNativeShare, setCanNativeShare] = useState(false);

  useEffect(() => {
    setCanNativeShare(typeof navigator !== 'undefined' && 'share' in navigator);
    if (!code) {
      setError('No gift code provided.');
      setLoading(false);
      return;
    }
    fetchGift(code)
      .then((g) => setGift(g))
      .catch(() => setError('We could not find that gift. It may have been removed.'))
      .finally(() => setLoading(false));
  }, [code]);

  const giftUrl = gift ? `${window.location.origin}/g/${gift.code}` : '';
  const shareText = gift ? `I made a digital gift for ${gift.recipient_name}! Open it here:` : 'I made you a digital gift! Open it here:';

  async function copyLink() {
    if (!giftUrl) return;
    try {
      await navigator.clipboard.writeText(giftUrl);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = giftUrl;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2500);
  }

  async function nativeShare() {
    if (!gift) return;
    try {
      await (navigator as Navigator & { share: (d: { title: string; text: string; url: string }) => Promise<void> }).share({
        title: `A gift for ${gift.recipient_name}`,
        text: shareText,
        url: giftUrl,
      });
    } catch {
      /* user dismissed */
    }
  }

  const channels = gift
    ? [
        { name: 'WhatsApp', icon: MessageCircle, bg: '#25D366', href: `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + giftUrl)}` },
        { name: 'Telegram', icon: Send, bg: '#229ED9', href: `https://t.me/share/url?url=${encodeURIComponent(giftUrl)}&text=${encodeURIComponent(shareText)}` },
        { name: 'X', icon: AtSign, bg: '#0f0f0f', href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(giftUrl)}` },
        { name: 'Facebook', icon: Globe, bg: '#1877F2', href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(giftUrl)}` },
        { name: 'Email', icon: Mail, bg: '#6b7280', href: `mailto:?subject=${encodeURIComponent(`A gift for ${gift.recipient_name}`)}&body=${encodeURIComponent(shareText + ' ' + giftUrl)}` },
        { name: 'SMS', icon: MessageSquare, bg: '#8b5cf6', href: `sms:?&body=${encodeURIComponent(shareText + ' ' + giftUrl)}` },
      ]
    : [];

  return (
    <div className="min-h-screen bg-[#FFF9F4]">
      <Navbar />
      <div className="mx-auto max-w-5xl px-4 pb-20 pt-28 sm:px-6 lg:px-8">
        {loading ? (
          <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4">
            <Loader2 size={36} className="animate-spin text-rose-500" />
            <p className="text-lg text-stone-500">Wrapping up the details…</p>
          </div>
        ) : error || !gift ? (
          <div className="mx-auto flex min-h-[50vh] max-w-md flex-col items-center justify-center gap-4 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-red-100 text-red-500"><AlertCircle size={30} /></span>
            <h1 className="font-display text-3xl font-bold">Gift not found</h1>
            <p className="text-stone-600">{error || 'Something went wrong.'}</p>
            <Link to="/create" className="mt-2 inline-flex items-center gap-2 rounded-full bg-stone-900 px-7 py-3 font-semibold text-white">
              <Gift size={18} /> Create a new gift
            </Link>
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-rose-500 via-rose-600 to-fuchsia-700 px-6 py-12 text-center text-white shadow-2xl sm:px-10">
              <EffectsLayer animation="sparkles" density="low" />
              <div className="relative">
                <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.15, type: 'spring', stiffness: 200 }}>
                  <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-white/20 backdrop-blur">
                    <PartyPopper size={38} />
                  </span>
                </motion.div>
                <h1 className="mt-5 font-display text-4xl font-bold sm:text-5xl">Your gift is ready!</h1>
                <p className="mx-auto mt-3 max-w-xl text-lg text-white/85">
                  Copy the link and send it to someone special — via WhatsApp, Instagram, Messages, or anywhere you like.
                </p>

                <div className="mx-auto mt-8 max-w-2xl rounded-2xl bg-white/15 p-2 backdrop-blur">
                  <div className="flex flex-col gap-2 rounded-xl bg-white p-2 sm:flex-row sm:items-center">
                    <p className="flex-1 truncate px-3 py-2.5 text-left font-mono text-[15px] font-semibold text-stone-800">{giftUrl}</p>
                    <button
                      onClick={copyLink}
                      className={`inline-flex items-center justify-center gap-2 rounded-xl px-7 py-3 font-bold text-white transition ${copied ? 'bg-emerald-500' : 'bg-stone-900 hover:bg-rose-600'}`}
                    >
                      {copied ? (<><Check size={18} /> Copied!</>) : (<><Copy size={18} /> Copy Link</>)}
                    </button>
                  </div>
                </div>

                <div className="mt-4 flex flex-col justify-center gap-3 sm:flex-row">
                  {canNativeShare && (
                    <button onClick={nativeShare} className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-7 py-3 font-bold text-rose-600 shadow-lg transition hover:scale-[1.02]">
                      <Share2 size={18} /> Share
                    </button>
                  )}
                  <Link to={`/g/${gift.code}`} className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-white/60 px-7 py-[10px] font-bold text-white transition hover:bg-white/10">
                    <Eye size={18} /> Preview as recipient
                  </Link>
                </div>
              </div>
            </div>

            <div className="mt-8 grid gap-6 lg:grid-cols-2">
              <div className="rounded-3xl border border-stone-100 bg-white p-6 shadow-sm sm:p-8">
                <h2 className="font-display text-2xl font-bold">Share it anywhere</h2>
                <p className="mt-1 text-[15px] text-stone-500">One tap to send through your favorite app. The link always opens this exact gift.</p>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  {channels.map((c) => (
                    <a
                      key={c.name}
                      href={c.href}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 font-bold text-white shadow-md transition hover:scale-[1.02] hover:shadow-lg"
                      style={{ background: c.bg }}
                    >
                      <c.icon size={18} /> {c.name}
                    </a>
                  ))}
                </div>
                <div className="mt-5 rounded-2xl bg-stone-50 p-4 text-sm leading-relaxed text-stone-600">
                  <p className="font-bold text-stone-800">Sharing on Instagram?</p>
                  <p className="mt-1">Copy the link above, then paste it into a DM, your story link sticker, or your bio. Your gift opens right in their browser.</p>
                </div>
              </div>

              <div>
                <GiftCard compact gift={gift} />
                <div className="mt-4 flex items-center justify-between rounded-2xl border border-stone-100 bg-white px-5 py-4 text-sm shadow-sm">
                  <span className="inline-flex items-center gap-2 text-stone-600"><Eye size={16} /> Opened {gift.views} {gift.views === 1 ? 'time' : 'times'} so far</span>
                  <Link to={`/g/${gift.code}`} className="inline-flex items-center gap-1 font-semibold text-rose-600 hover:text-rose-700">
                    Open gift <ExternalLink size={14} />
                  </Link>
                </div>
              </div>
            </div>

            <div className="mt-8 rounded-3xl bg-stone-900 p-6 text-white sm:p-8">
              <h2 className="font-display text-2xl font-bold">What happens next?</h2>
              <ol className="mt-4 space-y-3 text-[15px] text-white/75">
                <li className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 text-sm font-bold">1</span> Your recipient taps the link — no account or app needed.</li>
                <li className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 text-sm font-bold">2</span> They unwrap a magical reveal with your message, photos, music and animations.</li>
                <li className="flex gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 text-sm font-bold">3</span> You get all the credit — and probably a very happy message back.</li>
              </ol>
              <Link to="/create" className="mt-6 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 font-bold text-stone-900 transition hover:bg-rose-100">
                <Gift size={18} /> Create another gift
              </Link>
            </div>
          </motion.div>
        )}
      </div>
      <Footer />
    </div>
  );
}
