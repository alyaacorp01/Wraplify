import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertCircle, Gift, Heart, Loader2, Mail, MailOpen, Music, VolumeX, X,
} from 'lucide-react';
import EffectsLayer from '../components/EffectsLayer';
import { PatternOverlay } from '../components/GiftCard';
import { giftTypeById, musicById, themeById } from '../lib/giftData';
import type { Gift as GiftType } from '../lib/giftData';
import { bumpViews, fetchGift } from '../lib/api';

type Phase = 'loading' | 'sealed' | 'opening' | 'open' | 'error';

function Burst({ color }: { color: string }) {
  const [gone, setGone] = useState(false);
  const pieces = useMemo(
    () =>
      Array.from({ length: 70 }, (_, i) => ({
        x: (Math.random() - 0.5) * (typeof window !== 'undefined' ? window.innerWidth * 0.9 : 600),
        y: 200 + Math.random() * (typeof window !== 'undefined' ? window.innerHeight * 0.55 : 500),
        rot: Math.random() * 720 - 360,
        delay: Math.random() * 0.25,
        dur: 1.4 + Math.random() * 1.2,
        size: 6 + Math.random() * 10,
        color: [color, '#f59e0b', '#ffffff', '#f472b6', '#a78bfa'][i % 5],
        round: Math.random() > 0.6,
      })),
    [color]
  );
  useEffect(() => {
    const t = window.setTimeout(() => setGone(true), 3400);
    return () => window.clearTimeout(t);
  }, []);
  if (gone) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-50 flex items-start justify-center" aria-hidden="true">
      <div className="relative mt-[30vh] h-0 w-0">
        {pieces.map((p, i) => (
          <span
            key={i}
            className="fx-burst absolute block"
            style={{
              width: p.size,
              height: p.round ? p.size : p.size * 1.6,
              borderRadius: p.round ? '50%' : 2,
              background: p.color,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.dur}s`,
              ['--bx' as string]: `${p.x}px`,
              ['--by' as string]: `${p.y}px`,
              ['--br' as string]: `${p.rot}deg`,
            } as CSSProperties}
          />
        ))}
      </div>
    </div>
  );
}

function GiftBoxArt({ accent, opening }: { accent: string; opening: boolean }) {
  return (
    <div className={`relative mx-auto h-64 w-64 ${opening ? '' : 'animate-wiggle'}`}>
      <div className="animate-glow-pulse absolute inset-x-8 bottom-4 top-12 rounded-full blur-3xl" style={{ background: accent }} />
      {/* bow */}
      <motion.div
        className="absolute left-1/2 top-2 z-20 flex -translate-x-1/2 items-end"
        animate={opening ? { y: -150, rotate: -20, opacity: 0 } : { y: 0, rotate: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: 'easeIn' }}
      >
        <span className="h-9 w-12 -rotate-[24deg] rounded-[50%] border-4 border-white/90" style={{ background: accent }} />
        <span className="-mx-3 z-10 h-7 w-7 rounded-full border-4 border-white/90" style={{ background: accent }} />
        <span className="h-9 w-12 rotate-[24deg] rounded-[50%] border-4 border-white/90" style={{ background: accent }} />
      </motion.div>
      {/* lid */}
      <motion.div
        className="absolute left-1/2 top-12 z-10 h-14 w-60 -translate-x-1/2 rounded-2xl shadow-xl"
        style={{ background: accent }}
        animate={opening ? { y: -150, rotate: -16, opacity: 0 } : { y: 0, rotate: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: 'easeIn' }}
      >
        <div className="absolute inset-x-0 bottom-0 h-2 rounded-b-2xl bg-black/20" />
        <div className="absolute left-1/2 top-0 h-full w-10 -translate-x-1/2 bg-white/90" />
      </motion.div>
      {/* body */}
      <div className="absolute bottom-2 left-1/2 h-36 w-52 -translate-x-1/2 overflow-hidden rounded-b-3xl rounded-t-lg shadow-2xl" style={{ background: accent }}>
        <div className="absolute left-1/2 top-0 h-full w-10 -translate-x-1/2 bg-white/90" />
        <div className="absolute inset-x-0 top-0 h-2 bg-black/15" />
        {opening && (
          <motion.div
            className="absolute inset-0 bg-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 1] }}
            transition={{ duration: 0.6 }}
          />
        )}
      </div>
      {opening && (
        <motion.div
          className="absolute left-1/2 top-16 z-0 h-40 w-40 -translate-x-1/2 rounded-full bg-white blur-2xl"
          initial={{ scale: 0.2, opacity: 0 }}
          animate={{ scale: 2.4, opacity: [0, 1, 0.9] }}
          transition={{ duration: 0.8 }}
        />
      )}
    </div>
  );
}

export default function ViewGift() {
  const { code } = useParams<{ code: string }>();
  const [gift, setGift] = useState<GiftType | null>(null);
  const [phase, setPhase] = useState<Phase>('loading');
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [surpriseOpen, setSurpriseOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const bumped = useRef(false);

  useEffect(() => {
    if (!code) {
      setPhase('error');
      return;
    }
    fetchGift(code)
      .then((g) => {
        setGift(g);
        setPhase('sealed');
      })
      .catch(() => setPhase('error'));
  }, [code]);

  useEffect(() => {
    if (gift && !bumped.current) {
      bumped.current = true;
      bumpViews(gift.code);
    }
  }, [gift]);

  useEffect(() => {
    return () => {
      if (audioRef.current) audioRef.current.pause();
    };
  }, []);

  function startMusic(musicUrl: string | null) {
    if (!musicUrl) return;
    if (!audioRef.current) {
      audioRef.current = new Audio(musicUrl);
      audioRef.current.loop = true;
      audioRef.current.volume = 0.5;
    }
    audioRef.current.play().catch(() => undefined);
    setMuted(false);
  }

  function toggleMute() {
    if (!audioRef.current) return;
    if (audioRef.current.paused) {
      audioRef.current.play().catch(() => undefined);
      setMuted(false);
    } else {
      audioRef.current.pause();
      setMuted(true);
    }
  }

  function openGift() {
    if (!gift || phase !== 'sealed') return;
    setPhase('opening');
    startMusic(musicById(gift.music_id).url);
    window.setTimeout(() => setPhase('open'), 1500);
  }

  if (phase === 'loading') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#FFF9F4]">
        <Loader2 size={38} className="animate-spin text-rose-500" />
        <p className="text-lg text-stone-500">Finding your gift…</p>
      </div>
    );
  }

  if (phase === 'error' || !gift) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#FFF9F4] px-6 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-stone-200 text-stone-500"><AlertCircle size={30} /></span>
        <h1 className="font-display text-3xl font-bold">This gift link seems lost</h1>
        <p className="max-w-md text-stone-600">The link may be mistyped, or the gift may have been removed. Ask the sender to double-check the link.</p>
        <Link to="/" className="mt-2 inline-flex items-center gap-2 rounded-full bg-stone-900 px-7 py-3 font-semibold text-white">
          <Gift size={18} /> Go to Wraply
        </Link>
      </div>
    );
  }

  const theme = themeById(gift.theme_id);
  const type = giftTypeById(gift.gift_type);
  const music = musicById(gift.music_id);
  const isOpen = phase === 'open';

  return (
    <div className="relative min-h-screen overflow-hidden" style={{ background: theme.bg }}>
      <PatternOverlay bgId={gift.background_id} accent={theme.accent} dark={theme.dark} />
      <EffectsLayer animation={gift.animation_id} density={isOpen ? 'high' : 'low'} />
      {isOpen && <Burst color={theme.accent} />}

      {/* music toggle */}
      {isOpen && music.url && (
        <button
          onClick={toggleMute}
          className="fixed bottom-5 right-5 z-40 flex items-center justify-center rounded-full p-3.5 shadow-xl transition hover:scale-105"
          style={{ background: theme.accent, color: theme.accentInk }}
          aria-label={muted ? 'Play music' : 'Mute music'}
        >
          {muted ? <VolumeX size={20} /> : <Music size={20} className="animate-pulse" />}
        </button>
      )}

      <AnimatePresence mode="wait">
        {!isOpen ? (
          <motion.div
            key="sealed"
            exit={{ opacity: 0, scale: 1.04 }}
            transition={{ duration: 0.4 }}
            className="relative z-10 mx-auto flex min-h-screen max-w-2xl flex-col items-center justify-center px-6 py-16 text-center"
          >
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em]"
                style={{ background: theme.soft, color: theme.accent, border: `1px solid ${theme.accent}55` }}
              >
                <Gift size={13} /> You&apos;ve received a gift
              </span>
              <p className="mt-6 text-sm font-medium uppercase tracking-[0.35em]" style={{ color: theme.muted }}>
                A gift for
              </p>
              <h1 className="mt-1 font-script text-6xl leading-tight sm:text-7xl" style={{ color: theme.ink }}>
                {gift.recipient_name}
              </h1>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6, delay: 0.2 }}
              className="mt-8 cursor-pointer"
              onClick={openGift}
            >
              <GiftBoxArt accent={theme.accent} opening={phase === 'opening'} />
            </motion.div>

            {phase === 'sealed' ? (
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }} className="mt-6 flex flex-col items-center gap-4">
                <button
                  onClick={openGift}
                  className="relative inline-flex items-center gap-2.5 rounded-full px-10 py-4 text-lg font-bold shadow-2xl transition hover:scale-[1.03]"
                  style={{ background: theme.accent, color: theme.accentInk }}
                >
                  <span className="absolute inset-0 animate-ping rounded-full opacity-20" style={{ background: theme.accent }} />
                  <Gift size={20} /> Tap to open your gift
                </button>
                <p className="text-sm" style={{ color: theme.muted }}>from someone who cares about you</p>
              </motion.div>
            ) : (
              <p className="mt-8 animate-pulse font-script text-4xl" style={{ color: theme.ink }}>Opening…</p>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="open"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="relative z-10 mx-auto max-w-3xl px-4 py-14 sm:px-6 sm:py-20"
          >
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-center">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em]"
                style={{ background: theme.soft, color: theme.accent, border: `1px solid ${theme.accent}55` }}
              >
                <Heart size={12} fill="currentColor" /> {type.name}
              </span>
              <p className="mt-5 text-sm font-medium uppercase tracking-[0.35em]" style={{ color: theme.muted }}>A gift for</p>
              <h1 className="mt-1 font-script text-6xl leading-tight sm:text-8xl" style={{ color: theme.ink }}>
                {gift.recipient_name}
              </h1>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
              className="mt-10 rounded-[2rem] p-8 shadow-2xl backdrop-blur sm:p-10"
              style={{ background: theme.card, border: `1px solid ${theme.accent}44` }}
            >
              <p className="whitespace-pre-line text-center font-display text-xl leading-relaxed sm:text-2xl" style={{ color: theme.ink }}>
                “{gift.message}”
              </p>
            </motion.div>

            {gift.photos.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-10">
                <h2 className="text-center font-display text-2xl font-bold" style={{ color: theme.ink }}>Little moments, kept forever</h2>
                <div className={`mt-5 grid gap-3 ${gift.photos.length === 1 ? 'mx-auto grid-cols-1 max-w-md' : gift.photos.length === 2 ? 'grid-cols-2' : gift.photos.length === 3 ? 'grid-cols-3' : 'grid-cols-2 sm:grid-cols-3'}`}>
                  {gift.photos.map((src, i) => (
                    <button
                      key={i}
                      onClick={() => setLightbox(src)}
                      className={`overflow-hidden rounded-2xl border-4 shadow-xl transition hover:scale-[1.02] ${gift.photos.length >= 4 && i === 0 ? 'col-span-2 row-span-2' : ''} ${gift.photos.length === 1 ? 'aspect-[4/3]' : 'aspect-square'}`}
                      style={{ borderColor: 'rgba(255,255,255,0.85)' }}
                    >
                      <img src={src} alt={`Memory ${i + 1}`} className="h-full w-full object-cover" loading="lazy" />
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {gift.surprise_message && (
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="mt-12 text-center">
                {!surpriseOpen ? (
                  <button
                    onClick={() => setSurpriseOpen(true)}
                    className="mx-auto flex w-full max-w-md items-center gap-4 rounded-3xl p-5 text-left shadow-2xl backdrop-blur transition hover:scale-[1.01]"
                    style={{ background: theme.card, border: `2px dashed ${theme.accent}88` }}
                  >
                    <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-2xl" style={{ background: theme.accent, color: theme.accentInk }}>
                      <Mail size={26} />
                    </span>
                    <span>
                      <span className="block font-display text-lg font-bold" style={{ color: theme.ink }}>A surprise note is hidden here</span>
                      <span className="block text-sm" style={{ color: theme.muted }}>Tap to reveal what {gift.sender_name} tucked away for you</span>
                    </span>
                  </button>
                ) : (
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: 'spring', stiffness: 220 }}
                    className="mx-auto max-w-md rounded-3xl p-7 shadow-2xl backdrop-blur"
                    style={{ background: theme.card, border: `1px solid ${theme.accent}44` }}
                  >
                    <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full" style={{ background: theme.soft, color: theme.accent }}>
                      <MailOpen size={22} />
                    </span>
                    <p className="mt-2 text-xs font-bold uppercase tracking-[0.25em]" style={{ color: theme.muted }}>Surprise note</p>
                    <p className="mt-3 whitespace-pre-line font-display text-lg leading-relaxed" style={{ color: theme.ink }}>
                      {gift.surprise_message}
                    </p>
                  </motion.div>
                )}
              </motion.div>
            )}

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }} className="mt-12 text-center">
              <p className="text-base" style={{ color: theme.muted }}>
                With all my love,
              </p>
              <p className="mt-1 font-script text-5xl" style={{ color: theme.ink }}>{gift.sender_name}</p>
              {music.url && <p className="mt-3 inline-flex items-center gap-1.5 text-sm" style={{ color: theme.muted }}><Music size={14} /> Now playing: {music.name}</p>}
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }} className="mt-14 text-center">
              <div className="inline-flex flex-col items-center gap-3 rounded-3xl bg-black/25 px-8 py-6 backdrop-blur-md">
                <p className="text-sm text-white/80">Touched? Pass the feeling on.</p>
                <Link to="/create" className="inline-flex items-center gap-2 rounded-full bg-white px-7 py-3 font-bold text-stone-900 transition hover:scale-[1.03]">
                  <Gift size={18} /> Create your own gift
                </Link>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4"
            onClick={() => setLightbox(null)}
          >
            <button className="absolute right-5 top-5 rounded-full bg-white/15 p-2.5 text-white transition hover:bg-white/25" aria-label="Close">
              <X size={22} />
            </button>
            <motion.img
              initial={{ scale: 0.92 }} animate={{ scale: 1 }} exit={{ scale: 0.92 }}
              src={lightbox}
              alt="Gift memory"
              className="max-h-[85vh] max-w-full rounded-2xl shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
