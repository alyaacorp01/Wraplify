import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Cake, Check, Flower2, Gem, Gift, Heart, Images, Link2,
  MessageCircle, Music, PartyPopper, Play, Send, Share2, Sparkles, Users,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import GiftCard from '../components/GiftCard';
import EffectsLayer from '../components/EffectsLayer';
import { GIFT_TYPES, THEMES } from '../lib/giftData';
import { getGiftCount } from '../lib/api';

const TYPE_ICONS: Record<string, LucideIcon> = {
  love: Heart, birthday: Cake, anniversary: Gem, thanks: Flower2,
  congrats: PartyPopper, apology: MessageCircle, friendship: Users, justbecause: Sparkles,
};

const DEMO_PHOTOS = [
  'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=800&q=80',
];

const fadeUp = {
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-60px' },
};

export default function Home() {
  const [count, setCount] = useState(0);
  const [demoTheme, setDemoTheme] = useState('blush-rose');
  const [demoAnim, setDemoAnim] = useState('hearts');

  useEffect(() => {
    getGiftCount().then(setCount).catch(() => undefined);
  }, []);

  return (
    <div className="min-h-screen bg-[#FFF9F4] text-stone-900">
      <Navbar />

      {/* HERO */}
      <section className="relative overflow-hidden pb-16 pt-32 sm:pt-36 lg:pb-24 lg:pt-40">
        <div className="animate-drift pointer-events-none absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-rose-200/50 blur-3xl" />
        <div className="animate-drift pointer-events-none absolute -right-40 top-20 h-[460px] w-[460px] rounded-full bg-amber-200/50 blur-3xl" />
        <div className="pointer-events-none absolute left-1/3 top-64 h-[380px] w-[380px] rounded-full bg-fuchsia-200/40 blur-3xl" />
        <EffectsLayer animation="hearts" density="low" className="opacity-40" />

        <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:gap-10 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-2 rounded-full border border-rose-200 bg-white/80 px-4 py-1.5 text-sm font-medium text-rose-700 shadow-sm">
              <Sparkles size={15} />
              Digital gifts, wrapped in a link
            </span>
            <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-[4.4rem]">
              Create a digital gift. <span className="bg-gradient-to-r from-rose-500 to-fuchsia-600 bg-clip-text text-transparent">Get a link.</span> Send love.
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-stone-600">
              Personalize a beautiful gift with your words, photos, music and animations — then share one magical link. They open it like a real present. No account needed.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/create"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-stone-900 px-8 py-4 text-lg font-semibold text-white shadow-xl shadow-stone-900/20 transition hover:scale-[1.02] hover:bg-rose-600"
              >
                <Gift size={20} /> Create a Gift
              </Link>
              <Link
                to="/g/example8"
                className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-stone-200 bg-white/70 px-8 py-[14px] text-lg font-semibold text-stone-800 transition hover:border-rose-300 hover:text-rose-700"
              >
                <Play size={18} /> See an example
              </Link>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-x-7 gap-y-3 text-sm text-stone-500">
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-emerald-500" /> Free to create</span>
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-emerald-500" /> No account needed</span>
              <span className="inline-flex items-center gap-1.5"><Check size={16} className="text-emerald-500" /> Share anywhere</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.15 }}
            className="relative mx-auto w-full max-w-md lg:max-w-none"
          >
            <div className="absolute inset-8 rounded-[2.5rem] bg-gradient-to-br from-rose-400/30 to-fuchsia-500/30 blur-2xl" />
            <div className="animate-floaty relative" style={{ ['--r' as string]: '-2deg' } as CSSProperties}>
              <GiftCard
                compact
                gift={{
                  recipient_name: 'Sophia', sender_name: 'Daniel',
                  message: 'Every love story is beautiful, but ours will always be my favorite.',
                  gift_type: 'love', theme_id: 'blush-rose', background_id: 'hearts',
                  photos: DEMO_PHOTOS, music_id: 'tenderness',
                }}
              />
            </div>
            <div className="absolute -left-3 top-10 hidden rotate-[-6deg] items-center gap-2 rounded-2xl bg-white/95 px-4 py-3 shadow-xl sm:flex">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 text-emerald-600"><Link2 size={17} /></span>
              <div><p className="text-xs font-semibold text-stone-800">Link copied!</p><p className="text-[11px] text-stone-500">wraply.app/g/example8</p></div>
            </div>
            <div className="absolute -right-2 bottom-16 hidden rotate-[5deg] items-center gap-2 rounded-2xl bg-white/95 px-4 py-3 shadow-xl sm:flex">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-100 text-rose-600"><Heart size={17} fill="currentColor" /></span>
              <div><p className="text-xs font-semibold text-stone-800">Opened with tears</p><p className="text-[11px] text-stone-500">of joy, obviously</p></div>
            </div>
          </motion.div>
        </div>

        <div className="relative mx-auto mt-14 flex max-w-7xl flex-wrap items-center justify-center gap-3 px-4 text-sm sm:px-6">
          <span className="rounded-full bg-stone-900 px-5 py-2.5 font-semibold text-white">{count} gifts wrapped so far</span>
          <span className="rounded-full border border-stone-200 bg-white/70 px-5 py-2.5 text-stone-600">for birthdays, anniversaries &amp; just-because days</span>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="scroll-mt-24 bg-white py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-500">How it works</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">Three steps to their smile</h2>
          </motion.div>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { icon: Sparkles, step: 'Step 1', title: 'Personalize your gift', desc: 'Pick an occasion, write your message, add photos, choose a theme, animations and music. Watch it come alive in the live preview.', color: 'bg-rose-100 text-rose-600' },
              { icon: Link2, step: 'Step 2', title: 'Get your unique link', desc: 'Hit “Create Gift” and instantly receive a one-of-a-kind link made only for your gift. Copy it with a single tap.', color: 'bg-amber-100 text-amber-600' },
              { icon: Send, step: 'Step 3', title: 'Send it anywhere', desc: 'Share via WhatsApp, Instagram, Messages or email. They tap the link and unwrap a magical reveal — no account required.', color: 'bg-fuchsia-100 text-fuchsia-600' },
            ].map((s, i) => (
              <motion.div key={s.title} {...fadeUp} transition={{ delay: i * 0.1 }} className="relative rounded-3xl border border-stone-100 bg-[#FFF9F4] p-8 shadow-sm transition hover:shadow-xl">
                <span className={`inline-flex h-14 w-14 items-center justify-center rounded-2xl ${s.color}`}><s.icon size={26} /></span>
                <p className="mt-5 text-xs font-bold uppercase tracking-[0.2em] text-stone-400">{s.step}</p>
                <h3 className="mt-1 font-display text-2xl font-bold">{s.title}</h3>
                <p className="mt-2 leading-relaxed text-stone-600">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* OCCASIONS */}
      <section id="occasions" className="scroll-mt-24 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-500">Gift types</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">A gift for every feeling</h2>
            <p className="mt-4 text-lg text-stone-600">Eight curated occasions, each with heartfelt message starters and matching styles.</p>
          </motion.div>
          <div className="mt-14 grid grid-cols-2 gap-4 lg:grid-cols-4 lg:gap-6">
            {GIFT_TYPES.map((t, i) => {
              const Icon = TYPE_ICONS[t.id] ?? Heart;
              return (
                <motion.div key={t.id} {...fadeUp} transition={{ delay: (i % 4) * 0.08 }}>
                  <Link
                    to={`/create?type=${t.id}`}
                    className="group flex h-full flex-col rounded-3xl border border-stone-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
                  >
                    <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-500 to-fuchsia-600 text-white shadow-lg shadow-rose-500/25 transition group-hover:scale-110">
                      <Icon size={22} />
                    </span>
                    <h3 className="mt-4 font-display text-xl font-bold">{t.name}</h3>
                    <p className="mt-1 text-sm text-stone-500">{t.tagline}</p>
                    <span className="mt-auto inline-flex items-center gap-1 pt-4 text-sm font-semibold text-rose-600">
                      Create <ArrowRight size={15} className="transition group-hover:translate-x-1" />
                    </span>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* LIVE DEMO */}
      <section id="demo" className="scroll-mt-24 bg-[#170d1a] py-20 text-white lg:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <motion.div {...fadeUp}>
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-300">Interactive preview</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">Try the magic right here</h2>
            <p className="mt-4 text-lg text-white/65">Switch themes and animations to see how your gift could look. This is exactly what your recipient will unwrap.</p>
            <p className="mt-8 text-xs font-bold uppercase tracking-[0.2em] text-white/40">Pick a theme</p>
            <div className="mt-3 flex flex-wrap gap-2.5">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setDemoTheme(t.id)}
                  className={`h-11 w-11 rounded-full border-2 transition ${demoTheme === t.id ? 'scale-110 border-white' : 'border-white/20 hover:scale-105'}`}
                  style={{ background: t.swatch }}
                  title={t.name}
                  aria-label={t.name}
                />
              ))}
            </div>
            <p className="mt-6 text-xs font-bold uppercase tracking-[0.2em] text-white/40">Pick an animation</p>
            <div className="mt-3 flex flex-wrap gap-2.5">
              {['hearts', 'confetti', 'sparkles', 'petals', 'snow', 'fireworks'].map((a) => (
                <button
                  key={a}
                  onClick={() => setDemoAnim(a)}
                  className={`rounded-full px-4 py-2 text-sm font-medium capitalize transition ${demoAnim === a ? 'bg-white text-stone-900' : 'bg-white/10 text-white/70 hover:bg-white/20'}`}
                >
                  {a}
                </button>
              ))}
            </div>
            <Link to="/create" className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-fuchsia-600 px-7 py-3.5 font-semibold shadow-xl shadow-fuchsia-900/40 transition hover:scale-[1.02]">
              Make one like this <ArrowRight size={18} />
            </Link>
          </motion.div>
          <motion.div {...fadeUp} className="relative overflow-hidden rounded-[2rem]">
            <GiftCard
              gift={{
                recipient_name: 'Sophia', sender_name: 'Daniel',
                message: "If I had to choose again, I'd still choose you — in every lifetime, in every universe.",
                gift_type: 'love', theme_id: demoTheme, background_id: 'glow',
                photos: DEMO_PHOTOS, music_id: 'tenderness',
              }}
            />
            <EffectsLayer animation={demoAnim} density="low" />
          </motion.div>
        </div>
      </section>

      {/* MOMENTS */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-500">Made for moments</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">Big days &amp; small gestures</h2>
          </motion.div>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { img: '/images/moment-couple.jpg', title: 'Anniversaries', desc: 'Relive your favorite memories with photos, music and words from the heart.' },
              { img: '/images/moment-party.jpg', title: 'Birthdays', desc: 'Bursting confetti, cheerful tunes and a message they will screenshot forever.' },
              { img: '/images/moment-gift.jpg', title: 'Just because', desc: 'Turn an ordinary Tuesday into a day they will never forget.' },
            ].map((m, i) => (
              <motion.div key={m.title} {...fadeUp} transition={{ delay: i * 0.1 }} className="group overflow-hidden rounded-3xl bg-white shadow-sm transition hover:shadow-xl">
                <div className="h-60 overflow-hidden">
                  <img src={m.img} alt={m.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" loading="lazy" />
                </div>
                <div className="p-6">
                  <h3 className="font-display text-2xl font-bold">{m.title}</h3>
                  <p className="mt-1.5 text-stone-600">{m.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="bg-white py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-500">Everything included</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">Wrapped with thoughtful details</h2>
          </motion.div>
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Images, title: 'Photo memories', desc: 'Add up to 5 photos and turn your gift into a mini gallery of your favorite moments.' },
              { icon: Music, title: 'Music that sets the mood', desc: 'Choose a romantic piano piece or a cheerful tune that plays when they open it.' },
              { icon: Sparkles, title: 'Magical animations', desc: 'Floating hearts, falling petals, fireworks and more bring your gift to life.' },
              { icon: MessageCircle, title: 'Hidden surprise note', desc: 'Tuck away a secret message they can reveal with a tap — like a note in a box.' },
              { icon: Share2, title: 'Share anywhere', desc: 'One link works in WhatsApp, Instagram, Messages, email — anywhere you can paste.' },
              { icon: Users, title: 'No account needed', desc: 'Recipients just open the link. No sign-ups, no downloads, no friction. Pure delight.' },
            ].map((f, i) => (
              <motion.div key={f.title} {...fadeUp} transition={{ delay: (i % 3) * 0.08 }} className="rounded-3xl border border-stone-100 bg-[#FFF9F4] p-7">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-stone-900 text-white"><f.icon size={20} /></span>
                <h3 className="mt-4 text-lg font-bold">{f.title}</h3>
                <p className="mt-1 text-[15px] leading-relaxed text-stone-600">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeUp} className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-rose-500">Love notes</p>
            <h2 className="mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl">People are swooning</h2>
          </motion.div>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { quote: 'I sent one to my girlfriend on our anniversary and she called me crying happy tears before she even finished reading it.', name: 'Daniel R.', detail: 'Sent a Midnight Romance gift' },
              { quote: 'My mom opened hers at the dinner table and the whole family gathered around my phone. It felt like unwrapping something real.', name: 'Priya S.', detail: 'Sent a Birthday gift' },
              { quote: 'So easy — I made it on my lunch break and shared it on WhatsApp. The surprise note feature is genius.', name: 'Marcus T.', detail: 'Sent a Just Because gift' },
            ].map((t, i) => (
              <motion.figure key={t.name} {...fadeUp} transition={{ delay: i * 0.1 }} className="flex flex-col rounded-3xl bg-white p-8 shadow-sm">
                <div className="flex gap-1 text-amber-400">
                  {[0, 1, 2, 3, 4].map((s) => (<Heart key={s} size={15} fill="currentColor" />))}
                </div>
                <blockquote className="mt-4 flex-1 font-display text-lg leading-relaxed text-stone-800">“{t.quote}”</blockquote>
                <figcaption className="mt-6">
                  <p className="font-bold">{t.name}</p>
                  <p className="text-sm text-stone-500">{t.detail}</p>
                </figcaption>
              </motion.figure>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 pb-20 sm:px-6 lg:px-8 lg:pb-28">
        <motion.div {...fadeUp} className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-rose-500 via-rose-600 to-fuchsia-700 px-6 py-16 text-center text-white shadow-2xl sm:px-12 lg:py-20">
          <EffectsLayer animation="sparkles" density="low" />
          <div className="relative">
            <Gift size={44} className="mx-auto" strokeWidth={1.6} />
            <h2 className="mx-auto mt-5 max-w-2xl font-display text-4xl font-bold tracking-tight sm:text-5xl">Someone special is waiting for your gift</h2>
            <p className="mx-auto mt-4 max-w-xl text-lg text-white/80">It takes two minutes to create something they will remember for years.</p>
            <Link to="/create" className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-9 py-4 text-lg font-bold text-rose-600 shadow-xl transition hover:scale-[1.03]">
              <Gift size={20} /> Create a Gift — it&apos;s free
            </Link>
          </div>
        </motion.div>
      </section>

      <Footer />
    </div>
  );
}
