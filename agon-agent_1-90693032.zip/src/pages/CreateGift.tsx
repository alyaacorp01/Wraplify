import { useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertCircle, ArrowLeft, Ban, Cake, Check, Circle, Cloud, Eye, Flower2, Gem,
  Gift, Heart, Images, LayoutGrid, Loader2, MessageCircle, Music, PartyPopper,
  Pause, Play, Sparkles, Star, Sun, Users, Wand2, Waves, X, Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import GiftCard from '../components/GiftCard';
import EffectsLayer from '../components/EffectsLayer';
import { ANIMATIONS, BACKGROUNDS, GIFT_TYPES, MUSIC_TRACKS, THEMES, giftTypeById } from '../lib/giftData';
import { createGift, uploadPhoto } from '../lib/api';

const TYPE_ICONS: Record<string, LucideIcon> = {
  love: Heart, birthday: Cake, anniversary: Gem, thanks: Flower2,
  congrats: PartyPopper, apology: MessageCircle, friendship: Users, justbecause: Sparkles,
};

const ANIM_ICONS: Record<string, LucideIcon> = {
  hearts: Heart, confetti: PartyPopper, sparkles: Sparkles, petals: Flower2,
  snow: Star, balloons: Cloud, fireworks: Zap, bubbles: Circle, none: Ban,
};

const BG_ICONS: Record<string, LucideIcon> = {
  glow: Sun, hearts: Heart, stars: Star, dots: LayoutGrid, waves: Waves, none: Ban,
};

function Section({ step, title, desc, children }: { step: string; title: string; desc: string; children: ReactNode }) {
  return (
    <div className="rounded-3xl border border-stone-100 bg-white p-6 shadow-sm sm:p-8">
      <p className="text-xs font-bold uppercase tracking-[0.2em] text-rose-500">{step}</p>
      <h2 className="mt-1 font-display text-2xl font-bold">{title}</h2>
      <p className="mt-1 text-[15px] text-stone-500">{desc}</p>
      <div className="mt-5">{children}</div>
    </div>
  );
}

const inputCls = 'w-full rounded-xl border-2 border-stone-200 bg-white px-4 py-3 text-[15px] text-stone-900 placeholder:text-stone-400 outline-none transition focus:border-rose-400 focus:ring-4 focus:ring-rose-100';

export default function CreateGift() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialType = searchParams.get('type') || 'love';

  const [giftType, setGiftType] = useState(GIFT_TYPES.some((t) => t.id === initialType) ? initialType : 'love');
  const [recipient, setRecipient] = useState('');
  const [sender, setSender] = useState('');
  const [message, setMessage] = useState('');
  const [themeId, setThemeId] = useState('blush-rose');
  const [bgId, setBgId] = useState('glow');
  const [animId, setAnimId] = useState('hearts');
  const [musicId, setMusicId] = useState('tenderness');
  const [surpriseOn, setSurpriseOn] = useState(false);
  const [surprise, setSurprise] = useState('');
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [photoPreviews, setPhotoPreviews] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [apiError, setApiError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState('');
  const [playing, setPlaying] = useState<string | null>(null);
  const [mobilePreview, setMobilePreview] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const typeInfo = giftTypeById(giftType);

  function togglePlay(id: string, url: string | null) {
    if (!url) return;
    if (!audioRef.current) audioRef.current = new Audio();
    const audio = audioRef.current;
    if (playing === id) {
      audio.pause();
      setPlaying(null);
    } else {
      audio.src = url;
      audio.play().catch(() => undefined);
      setPlaying(id);
    }
  }

  function addFiles(files: FileList | null) {
    if (!files) return;
    const incoming = Array.from(files).filter((f) => f.type.startsWith('image/'));
    const room = 5 - photoFiles.length;
    const picked = incoming.slice(0, Math.max(0, room));
    if (picked.length === 0) return;
    setPhotoFiles((prev) => [...prev, ...picked]);
    setPhotoPreviews((prev) => [...prev, ...picked.map((f) => URL.createObjectURL(f))]);
  }

  function removePhoto(i: number) {
    URL.revokeObjectURL(photoPreviews[i]);
    setPhotoFiles((prev) => prev.filter((_, idx) => idx !== i));
    setPhotoPreviews((prev) => prev.filter((_, idx) => idx !== i));
  }

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!recipient.trim()) e.recipient = 'Please add who this gift is for.';
    else if (recipient.trim().length > 80) e.recipient = 'Keep the name under 80 characters.';
    if (sender.trim().length > 80) e.sender = 'Keep the name under 80 characters.';
    if (!message.trim()) e.message = 'Your message is the heart of the gift — write something lovely.';
    else if (message.trim().length > 2000) e.message = 'Keep the message under 2000 characters.';
    if (surpriseOn && surprise.trim().length > 1000) e.surprise = 'Keep the surprise under 1000 characters.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit() {
    setApiError('');
    if (!validate()) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setSubmitting(true);
    try {
      const urls: string[] = [];
      for (let i = 0; i < photoFiles.length; i++) {
        setStatus(`Uploading photo ${i + 1} of ${photoFiles.length}…`);
        urls.push(await uploadPhoto(photoFiles[i]));
      }
      setStatus('Wrapping your gift…');
      if (audioRef.current) audioRef.current.pause();
      const gift = await createGift({
        recipient_name: recipient.trim(),
        sender_name: sender.trim() || 'Someone who cares',
        message: message.trim(),
        surprise_message: surpriseOn && surprise.trim() ? surprise.trim() : null,
        gift_type: giftType,
        theme_id: themeId,
        background_id: bgId,
        animation_id: animId,
        music_id: musicId,
        photos: urls,
      });
      navigate(`/created/${gift.code}`);
    } catch (err) {
      setApiError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
      setSubmitting(false);
      setStatus('');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  const previewGift = {
    recipient_name: recipient, sender_name: sender, message,
    gift_type: giftType, theme_id: themeId, background_id: bgId,
    photos: photoPreviews, music_id: musicId,
  };

  return (
    <div className="min-h-screen bg-[#FFF9F4]">
      <Navbar />
      <div className="mx-auto max-w-7xl px-4 pb-28 pt-24 sm:px-6 lg:px-8 lg:pb-16">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm font-medium text-stone-500 hover:text-rose-600">
          <ArrowLeft size={16} /> Back home
        </Link>
        <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">Create your gift</h1>
            <p className="mt-2 text-lg text-stone-600">Personalize every detail — the preview updates live as you design.</p>
          </div>
          <button
            onClick={() => setMobilePreview(true)}
            className="inline-flex items-center gap-2 rounded-full border-2 border-stone-200 bg-white px-5 py-2.5 text-sm font-semibold lg:hidden"
          >
            <Eye size={16} /> Preview
          </button>
        </div>

        {apiError && (
          <div className="mt-6 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 text-[15px] text-red-700">
            <AlertCircle size={20} className="mt-0.5 shrink-0" />
            <p>{apiError}</p>
          </div>
        )}

        <div className="mt-8 grid items-start gap-6 lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_440px]">
          <div className="space-y-6">
            <Section step="Step 1" title="Choose the occasion" desc="What are you celebrating?">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {GIFT_TYPES.map((t) => {
                  const Icon = TYPE_ICONS[t.id] ?? Heart;
                  const active = giftType === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setGiftType(t.id)}
                      className={`flex flex-col items-center rounded-2xl border-2 p-4 text-center transition ${active ? 'border-rose-500 bg-rose-50 shadow-md' : 'bg-white hover:border-rose-300'}`}
                      style={active ? undefined : { borderColor: '#eee7e2' }}
                    >
                      <span className={`flex h-11 w-11 items-center justify-center rounded-xl ${active ? 'bg-gradient-to-br from-rose-500 to-fuchsia-600 text-white' : 'bg-stone-100 text-stone-500'}`}>
                        <Icon size={21} />
                      </span>
                      <span className="mt-2 text-sm font-bold">{t.name}</span>
                    </button>
                  );
                })}
              </div>
            </Section>

            <Section step="Step 2" title="Names & message" desc="The words they will treasure.">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1.5 block text-sm font-semibold">Recipient&apos;s name *</label>
                  <input value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder="e.g. Sophia" maxLength={80} className={inputCls} />
                  {errors.recipient && <p className="mt-1.5 text-sm text-red-600">{errors.recipient}</p>}
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-semibold">Your name</label>
                  <input value={sender} onChange={(e) => setSender(e.target.value)} placeholder="e.g. Daniel" maxLength={80} className={inputCls} />
                  {errors.sender && <p className="mt-1.5 text-sm text-red-600">{errors.sender}</p>}
                </div>
              </div>
              <div className="mt-4">
                <div className="mb-1.5 flex items-center justify-between">
                  <label className="text-sm font-semibold">Your message *</label>
                  <span className="text-xs text-stone-400">{message.length}/2000</span>
                </div>
                <textarea
                  value={message} onChange={(e) => setMessage(e.target.value)} rows={5} maxLength={2000}
                  placeholder="Pour your heart out…" className={`${inputCls} nice-scroll resize-y leading-relaxed`}
                />
                {errors.message && <p className="mt-1.5 text-sm text-red-600">{errors.message}</p>}
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-sm text-stone-500"><Wand2 size={15} /> Need inspiration?</span>
                  {typeInfo.samples.map((s, i) => (
                    <button key={i} onClick={() => setMessage(s)} className="rounded-full border border-rose-200 bg-rose-50 px-3.5 py-1.5 text-[13px] font-medium text-rose-700 transition hover:bg-rose-100">
                      Use sample {i + 1}
                    </button>
                  ))}
                </div>
              </div>
            </Section>

            <Section step="Step 3" title="Add photos" desc="Up to 5 photos of your favorite memories. (Optional)">
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
                {photoPreviews.map((src, i) => (
                  <div key={i} className="group relative aspect-square overflow-hidden rounded-2xl border-2 border-stone-200">
                    <img src={src} alt={`Upload ${i + 1}`} className="h-full w-full object-cover" />
                    <button onClick={() => removePhoto(i)} className="absolute right-1.5 top-1.5 rounded-full bg-black/60 p-1.5 text-white opacity-0 transition group-hover:opacity-100" aria-label="Remove photo">
                      <X size={14} />
                    </button>
                  </div>
                ))}
                {photoFiles.length < 5 && (
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-rose-300 bg-rose-50/50 text-rose-600 transition hover:bg-rose-50"
                  >
                    <Images size={26} />
                    <span className="px-2 text-center text-xs font-semibold">Add photo</span>
                  </button>
                )}
              </div>
              <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
              <p className="mt-3 text-[13px] text-stone-500">{photoFiles.length}/5 photos added. Images are compressed automatically for fast sharing.</p>
            </Section>

            <Section step="Step 4" title="Pick a theme" desc="Eight hand-crafted styles, from romantic to luxe.">
              <div className="grid grid-cols-2 gap-3">
                {THEMES.map((t) => {
                  const active = themeId === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setThemeId(t.id)}
                      className={`overflow-hidden rounded-2xl border-2 text-left transition ${active ? 'border-rose-500 shadow-lg' : 'border-transparent hover:scale-[1.01]'}`}
                    >
                      <div className="h-16" style={{ background: t.swatch }} />
                      <div className={`flex items-center justify-between px-3.5 py-2.5 ${active ? 'bg-rose-50' : 'bg-stone-50'}`}>
                        <div>
                          <p className="text-sm font-bold">{t.name}</p>
                          <p className="hidden text-xs text-stone-500 sm:block">{t.tagline}</p>
                        </div>
                        {active && <span className="flex h-6 w-6 items-center justify-center rounded-full bg-rose-500 text-white"><Check size={14} /></span>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </Section>

            <Section step="Step 5" title="Background pattern" desc="A subtle texture behind your gift.">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {BACKGROUNDS.map((b) => {
                  const Icon = BG_ICONS[b.id] ?? Sun;
                  const active = bgId === b.id;
                  return (
                    <button
                      key={b.id}
                      onClick={() => setBgId(b.id)}
                      className={`flex items-center gap-3 rounded-2xl border-2 p-3.5 text-left transition ${active ? 'border-rose-500 bg-rose-50' : 'bg-white hover:border-rose-300'}`}
                      style={active ? undefined : { borderColor: '#eee7e2' }}
                    >
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-rose-500 text-white' : 'bg-stone-100 text-stone-500'}`}><Icon size={19} /></span>
                      <span><span className="block text-sm font-bold">{b.name}</span><span className="block text-xs text-stone-500">{b.desc}</span></span>
                    </button>
                  );
                })}
              </div>
            </Section>

            <Section step="Step 6" title="Animation" desc="Bring the gift to life when it's opened.">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {ANIMATIONS.map((a) => {
                  const Icon = ANIM_ICONS[a.id] ?? Sparkles;
                  const active = animId === a.id;
                  return (
                    <button
                      key={a.id}
                      onClick={() => setAnimId(a.id)}
                      className={`flex items-center gap-3 rounded-2xl border-2 p-3.5 text-left transition ${active ? 'border-rose-500 bg-rose-50' : 'bg-white hover:border-rose-300'}`}
                      style={active ? undefined : { borderColor: '#eee7e2' }}
                    >
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-gradient-to-br from-rose-500 to-fuchsia-600 text-white' : 'bg-stone-100 text-stone-500'}`}><Icon size={19} /></span>
                      <span className="text-sm font-bold">{a.name}</span>
                    </button>
                  );
                })}
              </div>
            </Section>

            <Section step="Step 7" title="Music" desc="A melody that plays on open. Tap play to preview. (Optional)">
              <div className="space-y-2.5">
                {MUSIC_TRACKS.map((m) => {
                  const active = musicId === m.id;
                  const isPlaying = playing === m.id;
                  return (
                    <div
                      key={m.id}
                      onClick={() => setMusicId(m.id)}
                      className={`flex cursor-pointer items-center gap-3.5 rounded-2xl border-2 p-3.5 transition ${active ? 'border-rose-500 bg-rose-50' : 'bg-white hover:border-rose-300'}`}
                      style={active ? undefined : { borderColor: '#eee7e2' }}
                    >
                      {m.url ? (
                        <button
                          onClick={(e) => { e.stopPropagation(); togglePlay(m.id, m.url); }}
                          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition ${isPlaying ? 'bg-rose-500 text-white' : 'bg-stone-900 text-white hover:bg-rose-600'}`}
                          aria-label={isPlaying ? 'Pause preview' : 'Play preview'}
                        >
                          {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
                        </button>
                      ) : (
                        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-stone-100 text-stone-400"><Music size={18} /></span>
                      )}
                      <div className="flex-1">
                        <p className="text-[15px] font-bold">{m.name}</p>
                        <p className="text-[13px] text-stone-500">{m.mood}</p>
                      </div>
                      <span className={`flex h-6 w-6 items-center justify-center rounded-full border-2 ${active ? 'border-rose-500 bg-rose-500 text-white' : 'border-stone-300 text-transparent'}`}>
                        <Check size={14} />
                      </span>
                    </div>
                  );
                })}
              </div>
            </Section>

            <Section step="Step 8" title="Surprise note" desc="An optional hidden message revealed with a tap. (Optional)">
              <button
                onClick={() => setSurpriseOn(!surpriseOn)}
                className="flex w-full items-center justify-between rounded-2xl border-2 border-stone-200 bg-stone-50 p-4"
              >
                <span className="text-[15px] font-semibold">Include a hidden surprise note</span>
                <span className={`relative h-7 w-12 shrink-0 rounded-full transition ${surpriseOn ? 'bg-rose-500' : 'bg-stone-300'}`}>
                  <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${surpriseOn ? 'left-6' : 'left-1'}`} />
                </span>
              </button>
              {surpriseOn && (
                <div className="mt-4">
                  <textarea
                    value={surprise} onChange={(e) => setSurprise(e.target.value)} rows={3} maxLength={1000}
                    placeholder="P.S. Meet me under the old oak tree at sunset…" className={`${inputCls} nice-scroll resize-y`}
                  />
                  {errors.surprise && <p className="mt-1.5 text-sm text-red-600">{errors.surprise}</p>}
                </div>
              )}
            </Section>

            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2.5 rounded-3xl bg-stone-900 px-8 py-5 text-xl font-bold text-white shadow-xl transition hover:bg-rose-600 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {submitting ? (<><Loader2 size={22} className="animate-spin" /> {status || 'Creating…'} </>) : (<><Gift size={22} /> Create Gift</>)}
            </button>
          </div>

          {/* STICKY PREVIEW */}
          <aside className="sticky top-24 hidden lg:block">
            <div className="overflow-hidden rounded-3xl">
              <div className="relative">
                <GiftCard gift={previewGift} compact />
                <EffectsLayer animation={animId} density="low" />
              </div>
            </div>
            <p className="mt-3 text-center text-sm text-stone-500">
              <span className="inline-flex items-center gap-1.5"><Eye size={15} /> Live preview — updates as you type</span>
            </p>
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="mt-4 flex w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-rose-500 to-fuchsia-600 px-8 py-4 text-lg font-bold text-white shadow-xl shadow-rose-500/25 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {submitting ? (<><Loader2 size={20} className="animate-spin" /> {status || 'Creating…'} </>) : (<><Gift size={20} /> Create Gift</>)}
            </button>
          </aside>
        </div>
      </div>

      {/* MOBILE STICKY BAR */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-rose-100 bg-white/95 p-3 backdrop-blur-xl lg:hidden">
        <div className="flex gap-2.5">
          <button onClick={() => setMobilePreview(true)} className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border-2 border-stone-200 px-4 py-3.5 font-bold">
            <Eye size={18} /> Preview
          </button>
          <button onClick={handleSubmit} disabled={submitting} className="inline-flex flex-[2] items-center justify-center gap-2 rounded-2xl bg-stone-900 px-4 py-3.5 font-bold text-white disabled:opacity-70">
            {submitting ? (<><Loader2 size={18} className="animate-spin" /> Working…</>) : (<><Gift size={18} /> Create Gift</>)}
          </button>
        </div>
      </div>

      {/* MOBILE PREVIEW MODAL */}
      <AnimatePresence>
        {mobilePreview && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-4 sm:items-center"
            onClick={() => setMobilePreview(false)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
              className="nice-scroll relative max-h-[85vh] w-full max-w-md overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative">
                <GiftCard gift={previewGift} compact />
                <EffectsLayer animation={animId} density="low" />
              </div>
              <button onClick={() => setMobilePreview(false)} className="mt-3 w-full rounded-2xl bg-white py-3.5 font-bold shadow-xl">Close preview</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
}
