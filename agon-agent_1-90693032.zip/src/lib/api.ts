import type { Gift } from './giftData';

async function handle<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data as T;
}

export async function fetchGift(code: string): Promise<Gift> {
  const res = await fetch(`/api/gifts?code=${encodeURIComponent(code)}`);
  return handle<Gift>(res);
}

export async function getGiftCount(): Promise<number> {
  try {
    const res = await fetch('/api/gifts');
    const data = await handle<{ count: number }>(res);
    return data.count ?? 0;
  } catch {
    return 0;
  }
}

export interface CreateGiftPayload {
  recipient_name: string;
  sender_name: string;
  message: string;
  surprise_message: string | null;
  gift_type: string;
  theme_id: string;
  background_id: string;
  animation_id: string;
  music_id: string;
  photos: string[];
}

export async function createGift(payload: CreateGiftPayload): Promise<Gift> {
  const res = await fetch('/api/gifts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handle<Gift>(res);
}

export async function bumpViews(code: string): Promise<void> {
  try {
    await fetch('/api/gifts', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
  } catch {
    /* views are best-effort */
  }
}

/** Downscale + compress an image in the browser so uploads stay small and fast. */
export function processImage(file: File, maxDim = 1200, quality = 0.82): Promise<{ base64: string; contentType: string }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      try {
        let width = img.width;
        let height = img.height;
        const scale = Math.min(1, maxDim / Math.max(width, height));
        width = Math.max(1, Math.round(width * scale));
        height = Math.max(1, Math.round(height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Canvas not supported');
        ctx.drawImage(img, 0, 0, width, height);
        URL.revokeObjectURL(url);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve({ base64: dataUrl.split(',')[1], contentType: 'image/jpeg' });
      } catch (e) {
        URL.revokeObjectURL(url);
        reject(e);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Could not read that image file'));
    };
    img.src = url;
  });
}

export async function uploadPhoto(file: File): Promise<string> {
  const { base64, contentType } = await processImage(file);
  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
  const res = await fetch('/api/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fileName, fileBase64: base64, contentType }),
  });
  const data = await handle<{ url: string }>(res);
  return data.url;
}
