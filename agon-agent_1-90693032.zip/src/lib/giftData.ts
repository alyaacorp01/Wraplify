export interface Theme {
  id: string;
  name: string;
  tagline: string;
  bg: string;
  card: string;
  ink: string;
  muted: string;
  accent: string;
  accentInk: string;
  soft: string;
  dark: boolean;
  swatch: string;
}

export const THEMES: Theme[] = [
  {
    id: 'blush-rose', name: 'Blush Rose', tagline: 'Soft, romantic & timeless',
    bg: 'linear-gradient(140deg,#fff1f2 0%,#ffe4e6 45%,#fbcfe8 100%)',
    card: 'rgba(255,255,255,0.88)', ink: '#5b1f33', muted: '#a15c75',
    accent: '#e11d48', accentInk: '#ffffff', soft: '#ffe4e6', dark: false,
    swatch: 'linear-gradient(135deg,#fda4af,#e11d48)',
  },
  {
    id: 'midnight', name: 'Midnight Romance', tagline: 'Starry skies & stolen glances',
    bg: 'linear-gradient(140deg,#120b24 0%,#2a1650 55%,#4d1a5e 100%)',
    card: 'rgba(30,18,52,0.82)', ink: '#fdf4ff', muted: '#c9a9dc',
    accent: '#f0abfc', accentInk: '#3b0764', soft: 'rgba(240,171,252,0.16)', dark: true,
    swatch: 'linear-gradient(135deg,#2a1650,#a855f7)',
  },
  {
    id: 'golden', name: 'Golden Hour', tagline: 'Warm light, warmer feelings',
    bg: 'linear-gradient(140deg,#fffbeb 0%,#fef3c7 45%,#fcd34d 100%)',
    card: 'rgba(255,255,255,0.9)', ink: '#713f12', muted: '#a16207',
    accent: '#d97706', accentInk: '#ffffff', soft: '#fef3c7', dark: false,
    swatch: 'linear-gradient(135deg,#fde68a,#d97706)',
  },
  {
    id: 'lavender', name: 'Lavender Dream', tagline: 'Calm, dreamy & tender',
    bg: 'linear-gradient(140deg,#faf5ff 0%,#ede9fe 45%,#c4b5fd 100%)',
    card: 'rgba(255,255,255,0.88)', ink: '#4c1d95', muted: '#7d6bb5',
    accent: '#8b5cf6', accentInk: '#ffffff', soft: '#ede9fe', dark: false,
    swatch: 'linear-gradient(135deg,#c4b5fd,#8b5cf6)',
  },
  {
    id: 'mint', name: 'Mint Serenity', tagline: 'Fresh, gentle & sincere',
    bg: 'linear-gradient(140deg,#ecfdf5 0%,#d1fae5 50%,#6ee7b7 100%)',
    card: 'rgba(255,255,255,0.9)', ink: '#064e3b', muted: '#4d7c6f',
    accent: '#059669', accentInk: '#ffffff', soft: '#d1fae5', dark: false,
    swatch: 'linear-gradient(135deg,#6ee7b7,#059669)',
  },
  {
    id: 'cherry', name: 'Cherry Fete', tagline: 'Bold, festive & joyful',
    bg: 'linear-gradient(140deg,#fef2f2 0%,#fecaca 45%,#f87171 100%)',
    card: 'rgba(255,255,255,0.9)', ink: '#7f1d1d', muted: '#b45454',
    accent: '#dc2626', accentInk: '#ffffff', soft: '#fee2e2', dark: false,
    swatch: 'linear-gradient(135deg,#fca5a5,#dc2626)',
  },
  {
    id: 'ocean', name: 'Ocean Whisper', tagline: 'Deep, calm & true',
    bg: 'linear-gradient(140deg,#ecfeff 0%,#cffafe 45%,#67e8f9 100%)',
    card: 'rgba(255,255,255,0.9)', ink: '#0c4a6e', muted: '#4a7a9b',
    accent: '#0284c7', accentInk: '#ffffff', soft: '#cffafe', dark: false,
    swatch: 'linear-gradient(135deg,#67e8f9,#0284c7)',
  },
  {
    id: 'noir', name: 'Noir Luxe', tagline: 'Pure elegance in black & gold',
    bg: 'linear-gradient(140deg,#0c0a09 0%,#1c1917 55%,#44403c 100%)',
    card: 'rgba(28,25,23,0.85)', ink: '#faf5ec', muted: '#a8a29e',
    accent: '#d4af37', accentInk: '#1c1917', soft: 'rgba(212,175,55,0.16)', dark: true,
    swatch: 'linear-gradient(135deg,#292524,#d4af37)',
  },
];

export interface GiftTypeInfo {
  id: string;
  name: string;
  tagline: string;
  samples: string[];
}

export const GIFT_TYPES: GiftTypeInfo[] = [
  {
    id: 'love', name: 'For My Love', tagline: 'Say it with all your heart',
    samples: [
      'Every love story is beautiful, but ours will always be my favorite. Thank you for being my today, my tomorrow, my always.',
      "If I had to choose again, I'd still choose you — in every lifetime, in every universe.",
    ],
  },
  {
    id: 'birthday', name: 'Birthday', tagline: 'Make their day unforgettable',
    samples: [
      'Happy Birthday! Today we celebrate you — your laugh, your kindness, and every wonderful thing you bring into our lives.',
      "Another year more amazing! I hope this year brings you as much joy as you bring everyone else.",
    ],
  },
  {
    id: 'anniversary', name: 'Anniversary', tagline: 'Celebrate your story',
    samples: [
      "Happy Anniversary! Every chapter with you keeps getting better. Here's to all the ones still to come.",
      "Years pass, but my favorite place is still right next to you. Happy Anniversary, my love.",
    ],
  },
  {
    id: 'thanks', name: 'Thank You', tagline: 'Gratitude, beautifully wrapped',
    samples: [
      'Thank you — for everything, big and small. People like you make the world a kinder place.',
      'I just wanted you to know how much your kindness meant to me. Thank you, truly.',
    ],
  },
  {
    id: 'congrats', name: 'Congratulations', tagline: 'Cheer their big wins',
    samples: [
      "Congratulations! All your hard work paid off, and I couldn't be prouder of you. This is only the beginning!",
      "You did it! Take a moment to soak it all in — you've earned every bit of this success.",
    ],
  },
  {
    id: 'apology', name: "I'm Sorry", tagline: 'Mend it with sincerity',
    samples: [
      "I'm truly sorry. You mean more to me than my pride ever will, and I hope we can make this right.",
      'I was wrong, and I own it. Please forgive me — your happiness matters more to me than anything.',
    ],
  },
  {
    id: 'friendship', name: 'Friendship', tagline: 'For your favorite human',
    samples: [
      'Life is better with you in it. Thanks for every laugh, every late-night talk, and every memory.',
      "Some people make the world brighter just by being in it. You're one of them, my friend.",
    ],
  },
  {
    id: 'justbecause', name: 'Just Because', tagline: 'No reason. Just love.',
    samples: [
      "No occasion, no reason — I just wanted to remind you that you're loved, appreciated, and amazing.",
      'A little surprise for an ordinary day, because you deserve extraordinary things.',
    ],
  },
];

export interface BgOption { id: string; name: string; desc: string; }

export const BACKGROUNDS: BgOption[] = [
  { id: 'glow', name: 'Soft Glow', desc: 'Dreamy light halos' },
  { id: 'hearts', name: 'Sweethearts', desc: 'Scattered heart pattern' },
  { id: 'stars', name: 'Starlight', desc: 'Twinkling night sky' },
  { id: 'dots', name: 'Confetti Dots', desc: 'Playful polka dots' },
  { id: 'waves', name: 'Gentle Waves', desc: 'Flowing lines' },
  { id: 'none', name: 'Clean', desc: 'Pure & minimal' },
];

export interface AnimOption { id: string; name: string; }

export const ANIMATIONS: AnimOption[] = [
  { id: 'hearts', name: 'Floating Hearts' },
  { id: 'confetti', name: 'Confetti Rain' },
  { id: 'sparkles', name: 'Sparkles' },
  { id: 'petals', name: 'Rose Petals' },
  { id: 'snow', name: 'Snowfall' },
  { id: 'balloons', name: 'Balloons' },
  { id: 'fireworks', name: 'Fireworks' },
  { id: 'bubbles', name: 'Bubbles' },
  { id: 'none', name: 'Calm (none)' },
];

export interface MusicTrack { id: string; name: string; mood: string; url: string | null; }

export const MUSIC_TRACKS: MusicTrack[] = [
  { id: 'none', name: 'No music', mood: 'Silent & simple', url: null },
  { id: 'tenderness', name: 'Tenderness', mood: 'Soft piano', url: 'https://www.bensound.com/bensound-music/bensound-tenderness.mp3' },
  { id: 'love', name: 'Love', mood: 'Romantic acoustic', url: 'https://www.bensound.com/bensound-music/bensound-love.mp3' },
  { id: 'pianomoment', name: 'Piano Moment', mood: 'Gentle keys', url: 'https://www.bensound.com/bensound-music/bensound-pianomoment.mp3' },
  { id: 'sunny', name: 'Sunny', mood: 'Happy & bright', url: 'https://www.bensound.com/bensound-music/bensound-sunny.mp3' },
  { id: 'memories', name: 'Memories', mood: 'Nostalgic & warm', url: 'https://www.bensound.com/bensound-music/bensound-memories.mp3' },
];

export interface Gift {
  id: number;
  code: string;
  recipient_name: string;
  sender_name: string;
  message: string;
  surprise_message: string | null;
  gift_type: string;
  theme_id: string;
  background_id: string;
  animation_id: string;
  music_id: string;
  photos: string[];
  views: number;
  created_at: string;
}

export function themeById(id: string): Theme {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}

export function giftTypeById(id: string): GiftTypeInfo {
  return GIFT_TYPES.find((g) => g.id === id) ?? GIFT_TYPES[0];
}

export function musicById(id: string): MusicTrack {
  return MUSIC_TRACKS.find((m) => m.id === id) ?? MUSIC_TRACKS[0];
}
