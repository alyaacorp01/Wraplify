import supabase from './db-client.js';

function makeCode(len = 8) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { code } = req.query;
      if (code) {
        const { data, error } = await supabase.from('gifts').select('*').eq('code', code).single();
        if (error || !data) return res.status(404).json({ error: 'Gift not found' });
        return res.status(200).json(data);
      }
      const { count, error } = await supabase.from('gifts').select('*', { count: 'exact', head: true });
      if (error) throw error;
      return res.status(200).json({ count: count ?? 0 });
    }

    if (req.method === 'POST') {
      const b = req.body || {};
      const recipient_name = (b.recipient_name || '').toString().trim();
      const message = (b.message || '').toString().trim();
      if (!recipient_name) return res.status(400).json({ error: 'Recipient name is required' });
      if (!message) return res.status(400).json({ error: 'Message is required' });
      const row = {
        recipient_name: recipient_name.slice(0, 80),
        sender_name: (b.sender_name || 'Someone who cares').toString().trim().slice(0, 80) || 'Someone who cares',
        message: message.slice(0, 2000),
        surprise_message: b.surprise_message ? b.surprise_message.toString().trim().slice(0, 1000) || null : null,
        gift_type: (b.gift_type || 'love').toString().slice(0, 40),
        theme_id: (b.theme_id || 'blush-rose').toString().slice(0, 40),
        background_id: (b.background_id || 'glow').toString().slice(0, 40),
        animation_id: (b.animation_id || 'hearts').toString().slice(0, 40),
        music_id: (b.music_id || 'none').toString().slice(0, 40),
        photos: Array.isArray(b.photos) ? b.photos.filter((u) => typeof u === 'string').slice(0, 5) : [],
      };
      let created = null;
      let lastErr = null;
      for (let i = 0; i < 5; i++) {
        const code = makeCode(8);
        const { data, error } = await supabase.from('gifts').insert({ ...row, code }).select().single();
        if (!error) { created = data; break; }
        lastErr = error;
      }
      if (!created) throw lastErr || new Error('Could not create gift');
      return res.status(201).json(created);
    }

    if (req.method === 'PUT') {
      const { code } = req.body || {};
      if (!code) return res.status(400).json({ error: 'Code is required' });
      const { data: cur, error: selErr } = await supabase.from('gifts').select('views').eq('code', code).single();
      if (selErr) return res.status(404).json({ error: 'Gift not found' });
      const { error: upErr } = await supabase.from('gifts').update({ views: (cur?.views ?? 0) + 1 }).eq('code', code);
      if (upErr) throw upErr;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ error: err.message || 'Server error' });
  }
}
